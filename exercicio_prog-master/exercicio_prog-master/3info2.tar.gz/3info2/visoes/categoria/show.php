
<h1>Detalhes da Categoria - <?= $categoria->getNome() ?></h1>
<p><?= $categoria->getDescricao() ?></p>

