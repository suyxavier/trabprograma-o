<link rel="stylesheet" type="text/css" href="../assets/css/estilo.css">

<footer>
    <p>Endereco</p>
    <p>Telefone</p>
</footer>
</body>