<html>

<head>

    <title></title>

    <meta charset="utf-8"/>

    <link rel="stylesheet" type="text/css" href="../assets/semantic/semantic.css">

</head>

<body>


    <div class="ui inverted segment">

        <div class="ui inverted secondary pointing menu">

            <a class="active item">Home </a>
            <a class="item">Messages </a>
            <a class="item">Amigos </a>

        </div>

    </div>
